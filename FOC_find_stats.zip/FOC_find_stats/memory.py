num = 93
prob = 1
while num > 0:
    prob *= 1/num
    print("Probability of drawing perfect matches with " + str(num) + "cards remaining: " + str(prob*100) + " %")
    num -= 2
print("Final prob: " + str(prob*100) + " %")



from FOC_Fight import Fight
from FOC_Fighter import Fighter
import json
import datetime

def format_date(a_str):
    """Returns a date object"""
    pass

def compare_dates(date1, date2):
    pass


with open("FOC_fighter_stats.json", "r", encoding="utf-8") as handle:
    data = json.load(handle, strict=False)
data = data["data"]
fighter_key_list_strings = [str(fighter.keys()) for fighter in data]
fighter_names = [fighter[fighter.find("[")+2:fighter.rfind("]")-1] for fighter in fighter_key_list_strings]
fighter_dict = {a_fighter:{"stats":"","fights":""} for a_fighter in fighter_names}
test = data[0]
a_test = test["A.J. Matthews"]
print(a_test["fights"])
for i, fighter in enumerate(fighter_names):
    fighter_dict[fighter] = {"stats":data[i][fighter]["stats"],"fights":data[i][fighter]["fights"]}
for a_fighter in fighter_dict:
    fights = fighter_dict[a_fighter]["fights"]
    for a_fight in fights:
        print(a_fight["date"])




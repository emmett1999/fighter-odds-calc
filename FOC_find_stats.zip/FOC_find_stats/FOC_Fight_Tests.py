from FOC_Fight import Fight

def

if __name__ == "__main__":
    print("HJ")
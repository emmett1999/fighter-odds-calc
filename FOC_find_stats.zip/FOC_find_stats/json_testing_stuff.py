import json

with open("FOC_fighter_stats.json", "r", encoding="utf-8") as handle:
    data = json.load(handle, strict=False)

print(data)